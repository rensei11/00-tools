@echo off
setlocal EnableExtensions
set "LOG=%TEMP%\rensei_ai_voice_direct_start.log"

> "%LOG%" echo AI voice direct start started.

where wsl.exe >nul 2>&1
if errorlevel 1 goto no_wsl

wsl.exe -d Ubuntu -- bash -lc "echo c2V0IC1ldQpBUFA9CnNldCAtLSAvbW50L2QvKi9Jcm9kb3JpLVRUUy9GYW5kb20qL2FwcC5weQpmb3IgcCBpbiAiJEAiOyBkbwogIGlmIFsgLWYgIiRwIiBdOyB0aGVuCiAgICBBUFA9JHAKICAgIGJyZWFrCiAgZmkKZG9uZQppZiBbIC16ICIkQVBQIiBdOyB0aGVuCiAgZWNobyAiQUkgdm9pY2UgYXBwLnB5IHdhcyBub3QgZm91bmQgdW5kZXIgRCBkcml2ZS4iID4mMgogIGV4aXQgMjAKZmkKUFk9L2hvbWUvcmVuc2VpL0lyb2RvcmktVFRTLy52ZW52L2Jpbi9weXRob24KaWYgWyAhIC14ICIkUFkiIF07IHRoZW4KICBlY2hvICJJcm9kb3JpLVRUUyBQeXRob24gd2FzIG5vdCBmb3VuZC4iID4mMgogIGV4aXQgMjEKZmkKRElSPSQoZGlybmFtZSAiJEFQUCIpCmNkICIkRElSIgpub2h1cCAiJFBZIiBhcHAucHkgPi90bXAvcmVuc2VpX2FpX3ZvaWNlX2RpcmVjdF9zdGRvdXQubG9nIDI+L3RtcC9yZW5zZWlfYWlfdm9pY2VfZGlyZWN0X3N0ZGVyci5sb2cgPC9kZXYvbnVsbCAmCmV4aXQgMAo= | base64 -d | bash" >>"%LOG%" 2>&1
if errorlevel 1 goto start_failed

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; for($i=0;$i -lt 80;$i++){try{$r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:7862/' -TimeoutSec 2; if($r.StatusCode -eq 200){$ok=$true;break}}catch{}; Start-Sleep -Milliseconds 500}; if(-not $ok){exit 1}" >>"%LOG%" 2>&1
if errorlevel 1 goto app_failed

start "" "http://127.0.0.1:7862/"
echo AI voice direct start succeeded.
exit /b 0

:no_wsl
>>"%LOG%" echo ERROR: wsl.exe was not found.
type "%LOG%"
pause
exit /b 1

:start_failed
>>"%LOG%" echo ERROR: WSL direct start failed.
type "%LOG%"
pause
exit /b 1

:app_failed
>>"%LOG%" echo ERROR: AI voice app did not become ready.
type "%LOG%"
echo WSL stderr:
wsl.exe -d Ubuntu -- bash -lc "tail -n 80 /tmp/rensei_ai_voice_direct_stderr.log 2>/dev/null || true"
pause
exit /b 1
