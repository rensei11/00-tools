@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "LOG=%TEMP%\rensei_ai_voice_direct_start.log"
set "WLOG=%TEMP%\rensei_ai_voice_direct_wsl.log"
> "%LOG%" echo AI voice direct start v2 started.

where wsl.exe >nul 2>&1
if errorlevel 1 goto no_wsl

set "WSLIP="
for /f "usebackq tokens=1" %%I in (`wsl.exe -d Ubuntu -- bash -lc "echo c2V0IC1ldQpBUFA9CnNldCAtLSAvbW50L2QvKi9Jcm9kb3JpLVRUUy9GYW5kb20qL2FwcC5weQpmb3IgcCBpbiAiJEAiOyBkbwogIGlmIFsgLWYgIiRwIiBdOyB0aGVuCiAgICBBUFA9JHAKICAgIGJyZWFrCiAgZmkKZG9uZQppZiBbIC16ICIkQVBQIiBdOyB0aGVuCiAgZWNobyAiQUkgdm9pY2UgYXBwLnB5IHdhcyBub3QgZm91bmQgdW5kZXIgRCBkcml2ZS4iID4mMgogIGV4aXQgMjAKZmkKUFk9L2hvbWUvcmVuc2VpL0lyb2RvcmktVFRTLy52ZW52L2Jpbi9weXRob24KaWYgWyAhIC14ICIkUFkiIF07IHRoZW4KICBlY2hvICJJcm9kb3JpLVRUUyBQeXRob24gd2FzIG5vdCBmb3VuZC4iID4mMgogIGV4aXQgMjEKZmkKRElSPSQoZGlybmFtZSAiJEFQUCIpCkJJTkRfSVA9JChob3N0bmFtZSAtSSB8IGF3ayAne3ByaW50ICQxfScpCmlmIFsgLXogIiRCSU5EX0lQIiBdOyB0aGVuCiAgZWNobyAiV1NMIElQIGFkZHJlc3Mgd2FzIG5vdCBmb3VuZC4iID4mMgogIGV4aXQgMjIKZmkKY2QgIiRESVIiCnJtIC1mIC90bXAvcmVuc2VpX2FpX3ZvaWNlX2RpcmVjdDJfc3Rkb3V0LmxvZyAvdG1wL3JlbnNlaV9haV92b2ljZV9kaXJlY3QyX3N0ZGVyci5sb2cKbm9odXAgZW52IEFQUF9ESVI9IiRESVIiIEJJTkRfSVA9IiRCSU5EX0lQIiAiJFBZIiAtYyAnaW1wb3J0IG9zLHN5czsgZD1vcy5lbnZpcm9uWyJBUFBfRElSIl07IG9zLmNoZGlyKGQpOyBzeXMucGF0aC5pbnNlcnQoMCxkKTsgaW1wb3J0IGFwcDsgYXBwLmRlbW8ucXVldWUoZGVmYXVsdF9jb25jdXJyZW5jeV9saW1pdD0xKS5sYXVuY2goc2VydmVyX25hbWU9b3MuZW52aXJvblsiQklORF9JUCJdLCBzZXJ2ZXJfcG9ydD03ODYyLCBhbGxvd2VkX3BhdGhzPVtzdHIoYXBwLkFJX1JPT1QpXSknID4vdG1wL3JlbnNlaV9haV92b2ljZV9kaXJlY3QyX3N0ZG91dC5sb2cgMj4vdG1wL3JlbnNlaV9haV92b2ljZV9kaXJlY3QyX3N0ZGVyci5sb2cgPC9kZXYvbnVsbCAmCmVjaG8gJCEgPi90bXAvcmVuc2VpX2FpX3ZvaWNlX2RpcmVjdDIucGlkCnByaW50ZiAnJXNcbicgIiRCSU5EX0lQIgpleGl0IDAK ^| base64 -d ^| bash" 2^>^>"%LOG%"`) do (
    if not defined WSLIP set "WSLIP=%%I"
)
if not defined WSLIP goto start_failed

>>"%LOG%" echo WSL_IP=!WSLIP!

set "URL=http://!WSLIP!:7862/"
set /a TRY=0
:wait_ready
set /a TRY+=1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try{$r=Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -TimeoutSec 2; if($r.StatusCode -eq 200){exit 0}}catch{}; exit 1" >>"%LOG%" 2>&1
if not errorlevel 1 goto stable_check
if %TRY% GEQ 120 goto app_failed
timeout /t 1 /nobreak >nul
goto wait_ready

:stable_check
timeout /t 2 /nobreak >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try{$r=Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -TimeoutSec 2; if($r.StatusCode -eq 200){exit 0}}catch{}; exit 1" >>"%LOG%" 2>&1
if errorlevel 1 goto wait_ready

start "" "%URL%"
echo AI voice direct start succeeded.
exit /b 0

:no_wsl
>>"%LOG%" echo ERROR: wsl.exe was not found.
type "%LOG%"
pause
exit /b 1

:start_failed
>>"%LOG%" echo ERROR: WSL direct start failed before server launch.
wsl.exe -d Ubuntu -- bash -lc "tail -n 120 /tmp/rensei_ai_voice_direct2_stderr.log 2>/dev/null || true" >"%WLOG%" 2>&1
type "%LOG%"
type "%WLOG%"
pause
exit /b 1

:app_failed
>>"%LOG%" echo ERROR: AI voice app did not become reachable.
wsl.exe -d Ubuntu -- bash -lc "tail -n 120 /tmp/rensei_ai_voice_direct2_stderr.log 2>/dev/null || true" >"%WLOG%" 2>&1
type "%LOG%"
echo.
echo WSL error log:
type "%WLOG%"
pause
exit /b 1
